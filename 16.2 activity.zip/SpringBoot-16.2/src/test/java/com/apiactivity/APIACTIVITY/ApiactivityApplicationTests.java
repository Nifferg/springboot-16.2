package com.apiactivity.APIACTIVITY;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiactivityApplicationTests {

	@Test
	void contextLoads() {
	}

}
